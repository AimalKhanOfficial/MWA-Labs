import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-displaying-ng-for',
  template: `
    <ul>
      <li *ngFor="let names of cricketPlayerNames">
        {{names}}
      </li>
    </ul>

    <p appVisibilityDirective="true">Aimal Khan - Directive for visibility</p>
    <p appMynewcolor="yellow" (colorChangedEmitter)="colorChangedCry($event)">Directive for Color</p>
  `,
  styles: []
})
export class DisplayingNgForComponent implements OnInit {

  @Input('cricketPlayerNames') cricketPlayerNames;

  constructor() {

  }

  ngOnInit() {
    console.log(this.cricketPlayerNames);
  }

  colorChangedCry(evt){
    alert(evt);
  }

}
