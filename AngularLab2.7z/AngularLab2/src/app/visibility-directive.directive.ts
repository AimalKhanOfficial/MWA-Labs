import { Directive, Input, ElementRef, Renderer2, HostBinding } from '@angular/core';

@Directive({
  selector: '[appVisibilityDirective]'
})
export class VisibilityDirectiveDirective {
  @Input("appVisibilityDirective") appVisibilityDirective;
  constructor(private element: ElementRef, private renderer2: Renderer2) { }

  ngOnInit() {
    console.log(this.appVisibilityDirective);
    if (this.appVisibilityDirective === "false") {
      this.renderer2.setStyle(this.element.nativeElement, 'visibility', 'hidden');
    }
    else {
      this.renderer2.setStyle(this.element.nativeElement, 'visibility', 'visible');
    }
  }
}
