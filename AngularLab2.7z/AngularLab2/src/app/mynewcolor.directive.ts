import { Directive, Input, HostListener, ElementRef, Renderer2, Output, EventEmitter } from '@angular/core';

@Directive({
  selector: '[appMynewcolor]'
})
export class MynewcolorDirective {
  @Input("appMynewcolor") appMynewcolor;
  @Output() colorChangedEmitter = new EventEmitter();
  constructor(private element: ElementRef, private renderer2: Renderer2) { }

  @HostListener('click') onclick() {
    this.renderer2.setStyle(this.element.nativeElement, 'color', this.appMynewcolor);
    this.colorChangedEmitter.emit("Color is changed to: " + this.appMynewcolor);
  }

}
